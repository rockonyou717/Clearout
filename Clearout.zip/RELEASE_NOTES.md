## Clearout 1.0

- Galaxy A52 debloat profile with Recommended and Optional groups
- All apps list with search and locked system essentials
- Removed tab to restore anything with one tap
- Speed tools: animation speed, cache clearing, app optimizing, closing background apps
- Option to disable apps instead of removing them
