package dev.roki.clearout

import android.content.pm.PackageManager
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

/** Runs shell commands with ADB-level rights through Shizuku. */
object Shell {

    data class Result(val code: Int, val out: String) {
        val ok: Boolean
            get() = code == 0 && !out.contains("Failure") && !out.contains("Exception")
    }

    private val PACKAGE_NAME = Regex("^[A-Za-z0-9_.]+$")

    fun isSafePackage(pkg: String) = PACKAGE_NAME.matches(pkg)

    fun isRunning(): Boolean = try {
        Shizuku.pingBinder()
    } catch (e: Throwable) {
        false
    }

    fun hasPermission(): Boolean = try {
        isRunning() && Shizuku.checkSelfPermission() == PackageManager.PERMISSION_GRANTED
    } catch (e: Throwable) {
        false
    }

    // Shizuku keeps newProcess out of its public API, so it is called by reflection.
    private val newProcess by lazy {
        Shizuku::class.java.getDeclaredMethod(
            "newProcess",
            Array<String>::class.java,
            Array<String>::class.java,
            String::class.java
        ).apply { isAccessible = true }
    }

    suspend fun run(cmd: String): Result = withContext(Dispatchers.IO) {
        try {
            val process = newProcess.invoke(null, arrayOf("sh", "-c", "$cmd 2>&1"), null, null) as Process
            val out = process.inputStream.bufferedReader().readText()
            val code = process.waitFor()
            process.destroy()
            Result(code, out.trim())
        } catch (e: Throwable) {
            val cause = e.cause ?: e
            Result(-1, cause.message ?: cause.toString())
        }
    }

    fun parsePackages(out: String): Set<String> = out.lineSequence()
        .map { it.trim() }
        .filter { it.startsWith("package:") }
        .map { it.removePrefix("package:") }
        .toSet()
}
