package dev.roki.clearout

import android.view.LayoutInflater
import android.view.View
import android.view.ViewGroup
import android.widget.CheckBox
import android.widget.TextView
import androidx.recyclerview.widget.RecyclerView

data class Row(
    val key: String,
    val title: String,
    val subtitle: String = "",
    val note: String? = null,
    val badge: String? = null,
    val enabled: Boolean = true,
    val header: Boolean = false
)

class RowAdapter : RecyclerView.Adapter<RecyclerView.ViewHolder>() {

    var onChange: () -> Unit = {}
    val selected = LinkedHashSet<String>()
    private var rows: List<Row> = emptyList()

    fun submit(newRows: List<Row>) {
        rows = newRows
        val keys = selectableKeys().toSet()
        selected.retainAll(keys)
        notifyDataSetChanged()
        onChange()
    }

    fun selectableKeys(): List<String> = rows.filter { !it.header && it.enabled }.map { it.key }

    fun select(keys: Collection<String>) {
        selected.clear()
        selected.addAll(keys)
        notifyDataSetChanged()
        onChange()
    }

    fun isEmpty() = rows.none { !it.header }

    override fun getItemCount() = rows.size

    override fun getItemViewType(position: Int) = if (rows[position].header) 0 else 1

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): RecyclerView.ViewHolder {
        val inflater = LayoutInflater.from(parent.context)
        return if (viewType == 0) {
            object : RecyclerView.ViewHolder(inflater.inflate(R.layout.item_header, parent, false)) {}
        } else {
            AppHolder(inflater.inflate(R.layout.item_app, parent, false))
        }
    }

    override fun onBindViewHolder(holder: RecyclerView.ViewHolder, position: Int) {
        val row = rows[position]
        if (holder !is AppHolder) {
            (holder.itemView as TextView).text = row.title
            return
        }
        holder.title.text = row.title
        holder.subtitle.text = row.subtitle
        holder.subtitle.visibility = if (row.subtitle.isBlank()) View.GONE else View.VISIBLE
        holder.note.text = row.note ?: ""
        holder.note.visibility = if (row.note.isNullOrBlank()) View.GONE else View.VISIBLE
        holder.badge.text = row.badge ?: ""
        holder.badge.visibility = if (row.badge.isNullOrBlank()) View.GONE else View.VISIBLE
        holder.check.isChecked = row.key in selected
        holder.check.isEnabled = row.enabled
        holder.itemView.alpha = if (row.enabled) 1f else 0.5f
        holder.itemView.setOnClickListener {
            if (!row.enabled) return@setOnClickListener
            if (!selected.remove(row.key)) selected.add(row.key)
            val pos = holder.bindingAdapterPosition
            if (pos != RecyclerView.NO_POSITION) notifyItemChanged(pos)
            onChange()
        }
    }

    class AppHolder(view: View) : RecyclerView.ViewHolder(view) {
        val check: CheckBox = view.findViewById(R.id.check)
        val title: TextView = view.findViewById(R.id.title)
        val subtitle: TextView = view.findViewById(R.id.subtitle)
        val note: TextView = view.findViewById(R.id.note)
        val badge: TextView = view.findViewById(R.id.badge)
    }
}
