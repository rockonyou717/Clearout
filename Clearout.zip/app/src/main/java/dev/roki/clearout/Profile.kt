package dev.roki.clearout

enum class Tier(val title: String) {
    RECOMMENDED("Recommended: safe to remove"),
    OPTIONAL("Optional: remove only if you don't use it")
}

data class ProfileItem(val pkg: String, val label: String, val note: String, val tier: Tier)

/** Galaxy A52 debloat profile. Only packages actually on the phone are shown. */
object Profile {

    private fun r(pkg: String, label: String, note: String) = ProfileItem(pkg, label, note, Tier.RECOMMENDED)
    private fun o(pkg: String, label: String, note: String) = ProfileItem(pkg, label, note, Tier.OPTIONAL)

    val items: List<ProfileItem> = listOf(
        // Samsung extras
        r("com.samsung.android.app.spage", "Samsung Free", "News feed left of the home screen"),
        r("com.samsung.android.bixby.agent", "Bixby Voice", "Voice assistant"),
        r("com.samsung.android.bixby.wakeup", "Bixby wake-up", "Listens for the Bixby wake phrase"),
        r("com.samsung.android.bixbyvision.framework", "Bixby Vision framework", "Camera lens features"),
        r("com.samsung.android.visionintelligence", "Bixby Vision", "Camera lens features"),
        r("com.samsung.systemui.bixby2", "Bixby system hooks", "Bixby parts of the system UI"),
        r("com.samsung.android.app.settings.bixby", "Bixby settings", "Settings page for Bixby"),
        r("com.samsung.android.svoiceime", "Samsung voice input", "Voice typing for the Samsung keyboard"),
        r("com.samsung.android.app.tips", "Tips", "Samsung tips notifications"),
        r("com.samsung.android.voc", "Samsung Members", "Community and support app"),
        r("com.samsung.android.mateagent", "Galaxy Friends", "Accessory promo service"),
        r("com.samsung.android.arzone", "AR Zone", "AR camera hub"),
        r("com.samsung.android.aremoji", "AR Emoji", "Avatar camera"),
        r("com.samsung.android.aremojieditor", "AR Emoji editor", "Avatar editor"),
        r("com.samsung.android.ardrawing", "AR Doodle", "AR drawing camera"),
        r("com.sec.android.mimage.avatarstickers", "AR Emoji stickers", "Avatar sticker packs"),
        r("com.samsung.android.stickercenter", "Sticker center", "Sticker downloads"),
        r("com.samsung.android.livestickers", "Live stickers", "Animated sticker packs"),
        r("com.samsung.android.kidsinstaller", "Samsung Kids", "Kids mode installer"),
        r("com.samsung.android.tvplus", "Samsung TV Plus", "Free streaming TV app"),
        r("com.samsung.android.app.watchmanagerstub", "Galaxy Wearable stub", "Placeholder for the watch app"),
        r("com.samsung.android.hmt.vrsvc", "Gear VR service", "Old VR headset support"),
        r("com.samsung.android.app.vrsetupwizardstub", "Gear VR setup", "Old VR headset setup"),
        r("com.samsung.android.drivelink.stub", "Car mode stub", "Placeholder for car mode"),
        r("com.samsung.android.app.mirrorlink", "MirrorLink", "Old car screen mirroring"),
        r("com.samsung.android.rubin.app", "Customization Service", "Tracks usage for suggestions and ads"),
        r("com.samsung.android.ipsgeofence", "Visit In", "Location based suggestions"),
        r("com.samsung.android.beaconmanager", "Beacon manager", "Bluetooth beacon scanning"),
        r("com.samsung.android.service.peoplestripe", "People edge", "Contacts edge panel"),
        r("com.samsung.android.app.ledbackcover", "LED cover", "Support for LED view covers"),
        r("com.samsung.android.app.ledcoverdream", "LED cover screen", "Support for LED view covers"),
        r("com.samsung.android.coldwalletservice", "Blockchain Keystore", "Crypto wallet keystore"),
        r("com.samsung.android.smartswitchassistant", "Smart Switch agent", "Background helper for Smart Switch"),
        r("com.sec.android.app.chromecustomizations", "Chrome customizations", "Partner bookmarks for Chrome"),

        // Partner preloads
        r("com.facebook.katana", "Facebook", "Preinstalled Facebook"),
        r("com.facebook.appmanager", "Facebook App Manager", "Updates Facebook in the background"),
        r("com.facebook.services", "Facebook Services", "Background Facebook services"),
        r("com.facebook.system", "Facebook App Installer", "Installs Facebook apps"),
        r("com.microsoft.skydrive", "OneDrive", "Microsoft cloud storage preload"),
        r("com.microsoft.office.officehubrow", "Microsoft Office", "Office preload"),
        r("com.linkedin.android", "LinkedIn", "LinkedIn preload"),
        r("com.netflix.mediaclient", "Netflix", "Netflix preload"),
        r("com.netflix.partner.activation", "Netflix activation", "Netflix partner service"),
        r("com.google.android.feedback", "Google Feedback", "Sends crash reports to Google"),

        // Carrier and app-pusher bloat
        r("com.aura.oobe.samsung", "AppCloud", "Pushes sponsored apps"),
        r("com.aura.oobe.samsung.gl", "AppCloud", "Pushes sponsored apps"),
        r("com.ironsrc.aura.tmo", "App Selector", "Pushes sponsored apps"),
        r("com.LogiaGroup.LogiaDeck", "DT Ignite", "Pushes sponsored apps"),
        r("com.dti.att", "AT&T app installer", "Pushes sponsored apps"),
        r("com.dti.tracfone", "Tracfone app installer", "Pushes sponsored apps"),
        r("com.dti.folderlauncher", "App folder launcher", "Sponsored app folder"),
        r("com.tmobile.pr.mytmobile", "T-Life / T-Mobile", "Carrier account app"),
        r("com.att.myWireless", "myAT&T", "Carrier account app"),
        r("com.vzw.hss.myverizon", "My Verizon", "Carrier account app"),
        r("com.verizon.mips.services", "Verizon services", "Carrier background service"),

        // Only if unused
        o("com.samsung.android.game.gamehome", "Game Launcher", "Game hub and Game Booster"),
        o("com.samsung.android.game.gametools", "Game Booster tools", "In-game toolbar"),
        o("com.samsung.android.app.routines", "Modes and Routines", "Automation rules"),
        o("com.samsung.android.forest", "Samsung Digital Wellbeing", "Screen time tracking"),
        o("com.google.android.apps.wellbeing", "Google Digital Wellbeing", "Screen time tracking"),
        o("com.samsung.android.oneconnect", "SmartThings", "Smart home control"),
        o("com.samsung.android.spay", "Samsung Wallet", "Tap to pay"),
        o("com.samsung.android.spayfw", "Samsung Pay framework", "Needed by Samsung Wallet"),
        o("com.samsung.android.samsungpass", "Samsung Pass", "Password manager"),
        o("com.samsung.android.samsungpassautofill", "Samsung Pass autofill", "Autofill for Samsung Pass"),
        o("com.samsung.android.scloud", "Samsung Cloud", "Backup and sync"),
        o("com.samsung.android.fmm", "Find My Mobile", "Remote locate and wipe"),
        o("com.sec.android.easyMover", "Smart Switch", "Phone to phone transfer"),
        o("com.samsung.android.app.reminder", "Reminder", "Samsung reminders"),
        o("com.samsung.android.app.notes", "Samsung Notes", "Notes app"),
        o("com.samsung.android.email.provider", "Samsung Email", "Email app"),
        o("com.samsung.android.calendar", "Samsung Calendar", "Calendar app"),
        o("com.sec.android.app.voicenote", "Voice Recorder", "Recorder app"),
        o("com.sec.android.app.sbrowser", "Samsung Internet", "Install another browser first"),
        o("com.sec.android.app.samsungapps", "Galaxy Store", "Stops Samsung app updates"),
        o("com.samsung.android.app.aodservice", "Always On Display", "Clock on the off screen"),
        o("com.samsung.android.dynamiclock", "Dynamic Lock Screen", "Rotating lock screen wallpapers"),
        o("com.samsung.android.app.cocktailbarservice", "Edge panels", "Side swipe panels"),
        o("com.samsung.android.app.appsedge", "Apps edge", "Apps edge panel"),
        o("com.samsung.android.app.taskedge", "Tasks edge", "Tasks edge panel"),
        o("com.samsung.android.app.clipboardedge", "Clipboard edge", "Clipboard edge panel"),
        o("com.samsung.android.da.daagent", "Dual Messenger", "Second copy of chat apps"),
        o("com.samsung.android.privateshare", "Private Share", "Expiring file sharing"),
        o("com.samsung.android.app.simplesharing", "Link Sharing", "Share files by link"),
        o("com.samsung.android.mdx", "Link to Windows service", "PC phone link"),
        o("com.microsoft.appmanager", "Link to Windows", "PC phone link"),
        o("com.spotify.music", "Spotify", "Spotify preload"),
        o("com.google.android.apps.tachyon", "Google Meet", "Video calls"),
        o("com.google.android.apps.youtube.music", "YouTube Music", "Music app"),
        o("com.google.android.youtube", "YouTube", "Video app"),
        o("com.google.android.videos", "Google TV", "Movies and shows"),
        o("com.google.android.apps.docs", "Google Drive", "Cloud storage"),
        o("com.google.android.apps.photos", "Google Photos", "Photo backup"),
        o("com.google.android.gm", "Gmail", "Email app"),
        o("com.google.android.apps.maps", "Google Maps", "Maps app")
    )

    private val byPackage = items.associateBy { it.pkg }

    fun find(pkg: String): ProfileItem? = byPackage[pkg]

    /** Packages the phone needs to boot, call, install apps or show a home screen. */
    private val protectedExact = setOf(
        "android",
        "com.android.systemui",
        "com.android.settings",
        "com.android.phone",
        "com.android.shell",
        "com.android.server.telecom",
        "com.android.bluetooth",
        "com.android.nfc",
        "com.android.se",
        "com.android.keychain",
        "com.android.certinstaller",
        "com.android.inputdevices",
        "com.android.location.fused",
        "com.android.externalstorage",
        "com.android.documentsui",
        "com.google.android.documentsui",
        "com.android.permissioncontroller",
        "com.google.android.permissioncontroller",
        "com.android.packageinstaller",
        "com.google.android.packageinstaller",
        "com.google.android.gms",
        "com.google.android.gsf",
        "com.android.vending",
        "com.sec.android.app.launcher",
        "com.samsung.android.honeyboard",
        "com.sec.phone",
        "com.samsung.android.incallui",
        "com.samsung.android.dialer",
        "com.samsung.android.app.telephonyui",
        "com.sec.android.app.SecSetupWizard",
        "com.google.android.setupwizard",
        "com.samsung.android.biometrics.app.setting",
        "moe.shizuku.privileged.api",
        "dev.roki.clearout"
    )

    private val protectedPrefixes = listOf(
        "com.android.providers.",
        "com.sec.android.provider.",
        "com.android.networkstack",
        "com.google.android.networkstack",
        "com.android.wifi",
        "com.android.cellbroadcast",
        "com.google.android.cellbroadcast"
    )

    fun isProtected(pkg: String): Boolean =
        pkg in protectedExact || protectedPrefixes.any { pkg.startsWith(it) }
}
