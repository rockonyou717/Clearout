package dev.roki.clearout

import android.content.Intent
import android.content.pm.ApplicationInfo
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Bundle
import android.text.Editable
import android.text.TextWatcher
import android.view.LayoutInflater
import android.view.Menu
import android.view.MenuItem
import android.view.View
import android.view.ViewGroup
import android.widget.EditText
import android.widget.FrameLayout
import android.widget.LinearLayout
import android.widget.ProgressBar
import android.widget.ScrollView
import android.widget.TextView
import androidx.appcompat.app.AppCompatActivity
import androidx.lifecycle.lifecycleScope
import androidx.recyclerview.widget.LinearLayoutManager
import androidx.recyclerview.widget.RecyclerView
import com.google.android.material.appbar.MaterialToolbar
import com.google.android.material.bottomnavigation.BottomNavigationView
import com.google.android.material.button.MaterialButton
import com.google.android.material.card.MaterialCardView
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.google.android.material.materialswitch.MaterialSwitch
import com.google.android.material.snackbar.Snackbar
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import rikka.shizuku.Shizuku

enum class AppState { ACTIVE, DISABLED, REMOVED }

data class AppEntry(val pkg: String, val label: String, val system: Boolean, val state: AppState)

class MainActivity : AppCompatActivity() {

    private class ListPage(inflater: LayoutInflater, parent: ViewGroup) {
        val root: View = inflater.inflate(R.layout.page_list, parent, false)
        val hint: TextView = root.findViewById(R.id.pageHint)
        val search: EditText = root.findViewById(R.id.search)
        val toggle: MaterialSwitch = root.findViewById(R.id.toggle)
        val recycler: RecyclerView = root.findViewById(R.id.recycler)
        val empty: TextView = root.findViewById(R.id.empty)
        val progress: ProgressBar = root.findViewById(R.id.progress)
        val primary: MaterialButton = root.findViewById(R.id.primary)
        val secondary: MaterialButton = root.findViewById(R.id.secondary)
        val adapter = RowAdapter()

        init {
            recycler.layoutManager = LinearLayoutManager(root.context)
            recycler.adapter = adapter
        }
    }

    private lateinit var statusText: TextView
    private lateinit var statusButton: MaterialButton
    private lateinit var content: FrameLayout
    private lateinit var debloatPage: ListPage
    private lateinit var allPage: ListPage
    private lateinit var removedPage: ListPage
    private lateinit var speedPage: View
    private lateinit var speedLog: TextView

    private val prefs by lazy { getSharedPreferences("clearout", MODE_PRIVATE) }
    private var apps: Map<String, AppEntry> = emptyMap()
    private var loading = false
    private var busy = false

    private val binderReceived = Shizuku.OnBinderReceivedListener { runOnUiThread { refreshStatus() } }
    private val binderDead = Shizuku.OnBinderDeadListener { runOnUiThread { refreshStatus() } }
    private val permissionResult = Shizuku.OnRequestPermissionResultListener { _, _ ->
        runOnUiThread { refreshStatus() }
    }

    private val disableMode: Boolean
        get() = prefs.getBoolean("disable_mode", false)

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        setSupportActionBar(findViewById<MaterialToolbar>(R.id.toolbar))

        statusText = findViewById(R.id.statusText)
        statusButton = findViewById(R.id.statusButton)
        content = findViewById(R.id.content)

        val inflater = LayoutInflater.from(this)
        debloatPage = ListPage(inflater, content)
        allPage = ListPage(inflater, content)
        removedPage = ListPage(inflater, content)
        speedPage = buildSpeedPage()

        setupDebloatPage()
        setupAllPage()
        setupRemovedPage()

        listOf(debloatPage.root, allPage.root, removedPage.root, speedPage).forEach { content.addView(it) }
        showPage(R.id.nav_debloat)

        findViewById<BottomNavigationView>(R.id.bottomNav).setOnItemSelectedListener {
            showPage(it.itemId)
            true
        }

        Shizuku.addBinderReceivedListenerSticky(binderReceived)
        Shizuku.addBinderDeadListener(binderDead)
        Shizuku.addRequestPermissionResultListener(permissionResult)
    }

    override fun onResume() {
        super.onResume()
        refreshStatus()
    }

    override fun onDestroy() {
        Shizuku.removeBinderReceivedListener(binderReceived)
        Shizuku.removeBinderDeadListener(binderDead)
        Shizuku.removeRequestPermissionResultListener(permissionResult)
        super.onDestroy()
    }

    override fun onCreateOptionsMenu(menu: Menu): Boolean {
        menuInflater.inflate(R.menu.main_menu, menu)
        menu.findItem(R.id.action_disable_mode)?.isChecked = disableMode
        return true
    }

    override fun onOptionsItemSelected(item: MenuItem): Boolean {
        when (item.itemId) {
            R.id.action_disable_mode -> {
                val next = !item.isChecked
                item.isChecked = next
                prefs.edit().putBoolean("disable_mode", next).apply()
                updateButtons()
                toast(if (next) "Apps will be disabled instead of removed" else "Apps will be removed for your user")
            }
            R.id.action_refresh -> loadAll()
            R.id.action_about -> MaterialAlertDialogBuilder(this)
                .setTitle("Clearout ${BuildConfigCompat.versionName(this)}")
                .setMessage(getString(R.string.about_text))
                .setPositiveButton("OK", null)
                .show()
            else -> return super.onOptionsItemSelected(item)
        }
        return true
    }

    // region Status

    private fun refreshStatus() {
        when {
            !Shell.isRunning() -> {
                statusText.text = getString(R.string.status_not_running)
                statusButton.text = "Open Shizuku"
                statusButton.setOnClickListener { openShizuku() }
                showLocked()
            }
            !Shell.hasPermission() -> {
                statusText.text = getString(R.string.status_no_permission)
                statusButton.text = "Grant"
                statusButton.setOnClickListener { requestShizuku() }
                showLocked()
            }
            else -> {
                statusText.text = getString(R.string.status_ready)
                statusButton.text = "Refresh"
                statusButton.setOnClickListener { loadAll() }
                if (apps.isEmpty()) loadAll()
            }
        }
    }

    private fun requestShizuku() {
        try {
            if (Shizuku.shouldShowRequestPermissionRationale()) {
                toast("Access was denied. Allow Clearout in the Shizuku app.")
                openShizuku()
            } else {
                Shizuku.requestPermission(REQUEST_CODE)
            }
        } catch (e: Throwable) {
            toast("Shizuku is not running")
        }
    }

    private fun openShizuku() {
        val launch = packageManager.getLaunchIntentForPackage("moe.shizuku.privileged.api")
        val intent = launch ?: Intent(Intent.ACTION_VIEW, Uri.parse("https://shizuku.rikka.app/download/"))
        startActivity(intent)
    }

    private fun showLocked() {
        apps = emptyMap()
        val msg = "Connect Shizuku to see apps"
        listOf(debloatPage, allPage, removedPage).forEach {
            it.adapter.submit(emptyList())
            it.empty.text = msg
            it.empty.visibility = View.VISIBLE
        }
    }

    // endregion

    // region Pages

    private fun showPage(id: Int) {
        debloatPage.root.visibility = if (id == R.id.nav_debloat) View.VISIBLE else View.GONE
        allPage.root.visibility = if (id == R.id.nav_all) View.VISIBLE else View.GONE
        removedPage.root.visibility = if (id == R.id.nav_removed) View.VISIBLE else View.GONE
        speedPage.visibility = if (id == R.id.nav_speed) View.VISIBLE else View.GONE
    }

    private fun setupDebloatPage() = with(debloatPage) {
        hint.text = getString(R.string.hint_debloat)
        secondary.text = "Select recommended"
        secondary.setOnClickListener {
            val keys = adapter.selectableKeys().filter { Profile.find(it)?.tier == Tier.RECOMMENDED }
            adapter.select(if (adapter.selected.containsAll(keys) && keys.isNotEmpty()) emptyList() else keys)
        }
        primary.setOnClickListener { confirmRemove(adapter.selected.toList()) }
        adapter.onChange = { updateButtons() }
    }

    private fun setupAllPage() = with(allPage) {
        hint.text = getString(R.string.hint_all)
        search.visibility = View.VISIBLE
        toggle.visibility = View.VISIBLE
        toggle.text = "Show system apps"
        toggle.isChecked = true
        toggle.setOnCheckedChangeListener { _, _ -> renderAll() }
        search.addTextChangedListener(object : TextWatcher {
            override fun beforeTextChanged(s: CharSequence?, start: Int, count: Int, after: Int) {}
            override fun onTextChanged(s: CharSequence?, start: Int, before: Int, count: Int) {}
            override fun afterTextChanged(s: Editable?) = renderAll()
        })
        secondary.text = "Clear selection"
        secondary.setOnClickListener { adapter.select(emptyList()) }
        primary.setOnClickListener { confirmRemove(adapter.selected.toList()) }
        adapter.onChange = { updateButtons() }
    }

    private fun setupRemovedPage() = with(removedPage) {
        hint.text = getString(R.string.hint_removed)
        secondary.text = "Select all"
        secondary.setOnClickListener {
            val keys = adapter.selectableKeys()
            adapter.select(if (adapter.selected.size == keys.size && keys.isNotEmpty()) emptyList() else keys)
        }
        primary.setOnClickListener { confirmRestore(adapter.selected.toList()) }
        adapter.onChange = { updateButtons() }
    }

    private fun updateButtons() {
        val verb = if (disableMode) "Disable" else "Remove"
        debloatPage.primary.text = "$verb (${debloatPage.adapter.selected.size})"
        allPage.primary.text = "$verb (${allPage.adapter.selected.size})"
        removedPage.primary.text = "Restore (${removedPage.adapter.selected.size})"
        listOf(debloatPage, allPage, removedPage).forEach {
            it.primary.isEnabled = it.adapter.selected.isNotEmpty() && !busy
            it.secondary.isEnabled = !busy
        }
    }

    private fun setLoading(on: Boolean) {
        listOf(debloatPage, allPage, removedPage).forEach {
            it.progress.visibility = if (on) View.VISIBLE else View.GONE
            if (on) it.empty.visibility = View.GONE
        }
    }

    // endregion

    // region Data

    private fun loadAll() {
        if (!Shell.hasPermission() || loading) return
        loading = true
        setLoading(true)
        lifecycleScope.launch {
            val installed = Shell.parsePackages(Shell.run("pm list packages --user 0").out)
            val every = Shell.parsePackages(Shell.run("pm list packages -u --user 0").out)
            val disabled = Shell.parsePackages(Shell.run("pm list packages -d --user 0").out)
            val entries = withContext(Dispatchers.IO) {
                (every + installed).associateWith { pkg ->
                    val state = when {
                        pkg !in installed -> AppState.REMOVED
                        pkg in disabled -> AppState.DISABLED
                        else -> AppState.ACTIVE
                    }
                    buildEntry(pkg, state)
                }
            }
            apps = entries
            loading = false
            setLoading(false)
            if (installed.isEmpty()) toast("Could not read the app list. Restart Shizuku and try again.")
            renderAll()
        }
    }

    @Suppress("DEPRECATION")
    private fun buildEntry(pkg: String, state: AppState): AppEntry {
        val pm = packageManager
        val info: ApplicationInfo? = try {
            pm.getApplicationInfo(pkg, PackageManager.MATCH_UNINSTALLED_PACKAGES or PackageManager.MATCH_DISABLED_COMPONENTS)
        } catch (e: Exception) {
            null
        }
        val label = info?.loadLabel(pm)?.toString()?.takeIf { it.isNotBlank() && it != pkg }
            ?: Profile.find(pkg)?.label
            ?: pkg
        val system = info?.let { (it.flags and ApplicationInfo.FLAG_SYSTEM) != 0 } ?: true
        return AppEntry(pkg, label, system, state)
    }

    private fun renderAll() {
        renderDebloat()
        renderAllApps()
        renderRemoved()
        updateButtons()
    }

    private fun renderDebloat() {
        val rows = mutableListOf<Row>()
        for (tier in Tier.values()) {
            val items = Profile.items.filter { it.tier == tier && apps[it.pkg]?.state == AppState.ACTIVE }
            if (items.isEmpty()) continue
            rows += Row(key = "header_${tier.name}", title = tier.title, header = true)
            items.forEach { rows += Row(key = it.pkg, title = it.label, subtitle = it.pkg, note = it.note) }
        }
        debloatPage.adapter.submit(rows)
        showEmpty(debloatPage, "Nothing left to remove. This phone is clean.")
    }

    private fun renderAllApps() {
        val query = allPage.search.text?.toString()?.trim()?.lowercase().orEmpty()
        val showSystem = allPage.toggle.isChecked
        val rows = apps.values
            .filter { it.state == AppState.ACTIVE }
            .filter { showSystem || !it.system }
            .filter { query.isEmpty() || it.label.lowercase().contains(query) || it.pkg.lowercase().contains(query) }
            .sortedBy { it.label.lowercase() }
            .map { app ->
                val locked = Profile.isProtected(app.pkg)
                Row(
                    key = app.pkg,
                    title = app.label,
                    subtitle = app.pkg,
                    note = if (locked) "Protected: the phone needs this" else Profile.find(app.pkg)?.note,
                    badge = if (app.system) "System" else "User",
                    enabled = !locked
                )
            }
        allPage.adapter.submit(rows)
        showEmpty(allPage, "No apps match")
    }

    private fun renderRemoved() {
        val rows = apps.values
            .filter { it.state != AppState.ACTIVE }
            .sortedBy { it.label.lowercase() }
            .map {
                Row(
                    key = it.pkg,
                    title = it.label,
                    subtitle = it.pkg,
                    badge = if (it.state == AppState.REMOVED) "Removed" else "Disabled"
                )
            }
        removedPage.adapter.submit(rows)
        showEmpty(removedPage, "Nothing removed yet")
    }

    private fun showEmpty(page: ListPage, msg: String) {
        page.empty.text = msg
        page.empty.visibility = if (page.adapter.isEmpty() && !loading) View.VISIBLE else View.GONE
    }

    // endregion

    // region Actions

    private fun confirmRemove(pkgs: List<String>) {
        val safe = pkgs.filter { Shell.isSafePackage(it) && !Profile.isProtected(it) }
        if (safe.isEmpty()) return
        val disable = disableMode
        val names = safe.take(12).joinToString("\n") { apps[it]?.label ?: it } +
            if (safe.size > 12) "\nand ${safe.size - 12} more" else ""
        MaterialAlertDialogBuilder(this)
            .setTitle(if (disable) "Disable ${safe.size} apps?" else "Remove ${safe.size} apps?")
            .setMessage("$names\n\n${getString(R.string.confirm_note)}")
            .setNegativeButton("Cancel", null)
            .setPositiveButton(if (disable) "Disable" else "Remove") { _, _ ->
                runBatch(
                    pkgs = safe,
                    doneVerb = if (disable) "Disabled" else "Removed",
                    command = { if (disable) "pm disable-user --user 0 $it" else "pm uninstall -k --user 0 $it" },
                    success = { r -> r.ok && (r.out.contains("Success") || r.out.contains("disabled")) }
                )
            }
            .show()
    }

    private fun confirmRestore(pkgs: List<String>) {
        val safe = pkgs.filter { Shell.isSafePackage(it) }
        if (safe.isEmpty()) return
        MaterialAlertDialogBuilder(this)
            .setTitle("Restore ${safe.size} apps?")
            .setMessage("They come back exactly as they shipped with the phone.")
            .setNegativeButton("Cancel", null)
            .setPositiveButton("Restore") { _, _ ->
                runBatch(
                    pkgs = safe,
                    doneVerb = "Restored",
                    command = { "cmd package install-existing --user 0 $it; pm enable --user 0 $it" },
                    success = { r -> r.out.contains("installed for user") || r.out.contains("new state: enabled") }
                )
            }
            .show()
    }

    private fun runBatch(
        pkgs: List<String>,
        doneVerb: String,
        command: (String) -> String,
        success: (Shell.Result) -> Boolean
    ) {
        if (busy) return
        busy = true
        updateButtons()
        setLoading(true)
        lifecycleScope.launch {
            val failed = mutableListOf<String>()
            for (pkg in pkgs) {
                val result = Shell.run(command(pkg))
                if (!success(result)) failed += "${apps[pkg]?.label ?: pkg}: ${result.out.lineSequence().firstOrNull().orEmpty()}"
            }
            busy = false
            listOf(debloatPage, allPage, removedPage).forEach { it.adapter.selected.clear() }
            loadAll()
            val okCount = pkgs.size - failed.size
            if (failed.isEmpty()) {
                Snackbar.make(content, "$doneVerb $okCount apps", Snackbar.LENGTH_LONG).show()
            } else {
                MaterialAlertDialogBuilder(this@MainActivity)
                    .setTitle("$doneVerb $okCount of ${pkgs.size}")
                    .setMessage("These did not work:\n\n" + failed.joinToString("\n"))
                    .setPositiveButton("OK", null)
                    .show()
            }
        }
    }

    // endregion

    // region Speed

    private data class SpeedAction(val title: String, val desc: String, val button: String, val cmd: String)

    private val speedActions = listOf(
        SpeedAction(
            "Faster animations", "Sets all animation speeds to 0.5x. The phone feels much snappier.", "Apply 0.5x",
            "settings put global window_animation_scale 0.5; settings put global transition_animation_scale 0.5; settings put global animator_duration_scale 0.5"
        ),
        SpeedAction(
            "Turn off animations", "Instant screen changes. Fastest, but less smooth to look at.", "Turn off",
            "settings put global window_animation_scale 0; settings put global transition_animation_scale 0; settings put global animator_duration_scale 0"
        ),
        SpeedAction(
            "Reset animations", "Back to the normal 1x speed.", "Reset",
            "settings put global window_animation_scale 1; settings put global transition_animation_scale 1; settings put global animator_duration_scale 1"
        ),
        SpeedAction(
            "Clear app caches", "Deletes cached files from every app. Frees storage, logs nobody out.", "Clear caches",
            "pm trim-caches 999G && echo Caches cleared"
        ),
        SpeedAction(
            "Optimize apps", "Recompiles apps so they open faster. Can take a few minutes. Keep the screen on.", "Optimize",
            "cmd package bg-dexopt-job && echo Optimization finished"
        ),
        SpeedAction(
            "Close background apps", "Stops apps sitting in the background to free up memory.", "Close apps",
            "am kill-all && echo Background apps closed"
        )
    )

    private fun buildSpeedPage(): View {
        val dp = resources.displayMetrics.density
        val scroll = ScrollView(this)
        val column = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding((16 * dp).toInt(), (8 * dp).toInt(), (16 * dp).toInt(), (16 * dp).toInt())
        }
        scroll.addView(column)

        val buttons = mutableListOf<MaterialButton>()
        for (action in speedActions) {
            val card = layoutInflater.inflate(R.layout.item_speed, column, false) as MaterialCardView
            card.findViewById<TextView>(R.id.speedTitle).text = action.title
            card.findViewById<TextView>(R.id.speedDesc).text = action.desc
            val button = card.findViewById<MaterialButton>(R.id.speedButton)
            button.text = action.button
            button.setOnClickListener { runSpeed(action, buttons) }
            buttons += button
            column.addView(card)
        }

        speedLog = TextView(this).apply {
            setTextIsSelectable(true)
            setPadding(0, (12 * dp).toInt(), 0, 0)
            alpha = 0.8f
        }
        column.addView(speedLog)
        return scroll
    }

    private fun runSpeed(action: SpeedAction, buttons: List<MaterialButton>) {
        if (!Shell.hasPermission()) {
            toast("Connect Shizuku first")
            return
        }
        buttons.forEach { it.isEnabled = false }
        speedLog.text = "${action.title}: running..."
        lifecycleScope.launch {
            val result = Shell.run(action.cmd)
            val out = result.out.ifBlank { if (result.code == 0) "Done" else "Failed (code ${result.code})" }
            speedLog.text = "${action.title}: $out"
            buttons.forEach { it.isEnabled = true }
        }
    }

    // endregion

    private fun toast(msg: String) = Snackbar.make(content, msg, Snackbar.LENGTH_SHORT).show()

    companion object {
        private const val REQUEST_CODE = 41
    }
}

object BuildConfigCompat {
    fun versionName(activity: AppCompatActivity): String = try {
        activity.packageManager.getPackageInfo(activity.packageName, 0).versionName ?: ""
    } catch (e: Exception) {
        ""
    }
}
