# Clearout

Debloater and speed tools for Samsung phones, built for a Galaxy A52 test phone. Runs through Shizuku, so no root and no PC.

## Setup
1. Install Shizuku from the Play Store.
2. Settings > About phone > Software information, tap Build number 7 times.
3. Settings > Developer options, turn on Wireless debugging.
4. In Shizuku, pick Start via Wireless debugging and pair using the code it shows.
5. Open Clearout and tap Grant.

After a reboot, start Shizuku again before using Clearout.

## Safety
Removals use `pm uninstall --user 0`, so nothing is deleted from the system. Restore anything from the Removed tab, or factory reset to bring everything back.

Made by Roki Rodriguez.
